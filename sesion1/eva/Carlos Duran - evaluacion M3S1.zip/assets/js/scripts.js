const pi = Math.PI
let radio = 5

let area = ( pi * (radio ** 2))

console.log("El área del círculo es: " + area)